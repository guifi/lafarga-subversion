#!/bin/bash
php ../graphs/mrtgcsv2mrtgcfg.php

<?php
$rrdtool_path='/usr/bin/rrdtool';
$rrddb_path='/home1/comesfa/mrtg/logs/';
// -------- XML file Load ---------------
$xml = simplexml_load_file('guifi.xml');
?>

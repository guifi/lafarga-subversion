#!/bin/bash
# Refreshing CNML local file (optional)
php refresh_cnml.php
